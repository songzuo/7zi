var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0bu702s._.js")
R.c("server/chunks/[root-of-the-server]__0daxsrt._.js")
R.m(89997)
module.exports=R.m(89997).exports
