var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/github/commits/route.js")
R.c("server/chunks/[root-of-the-server]__07ydv17._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_github_commits_route_actions_0tz0vqu.js")
R.m(50248)
module.exports=R.m(50248).exports
