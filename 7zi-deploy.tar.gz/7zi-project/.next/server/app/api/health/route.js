var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__0nz2ft4._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_0-jjhgq.js")
R.m(43007)
module.exports=R.m(43007).exports
