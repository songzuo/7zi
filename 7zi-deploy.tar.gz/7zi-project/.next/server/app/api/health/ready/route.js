var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/ready/route.js")
R.c("server/chunks/[root-of-the-server]__00doz9p._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_health_ready_route_actions_0.o_5fo.js")
R.m(47003)
module.exports=R.m(47003).exports
