var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/detailed/route.js")
R.c("server/chunks/[root-of-the-server]__07go7i-._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_health_detailed_route_actions_0o1-ng1.js")
R.m(25994)
module.exports=R.m(25994).exports
