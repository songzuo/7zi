var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/live/route.js")
R.c("server/chunks/[root-of-the-server]__01ntes_._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_health_live_route_actions_0cdl2kj.js")
R.m(53126)
module.exports=R.m(53126).exports
