var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/status/route.js")
R.c("server/chunks/[root-of-the-server]__0hr6x78._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_status_route_actions_0_p_uf5.js")
R.m(92053)
module.exports=R.m(92053).exports
