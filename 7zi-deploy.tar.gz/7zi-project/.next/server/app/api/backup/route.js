var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/backup/route.js")
R.c("server/chunks/[root-of-the-server]__02jl1o6._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_backup_route_actions_0i7_4tr.js")
R.m(14249)
module.exports=R.m(14249).exports
