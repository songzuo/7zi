var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/export/route.js")
R.c("server/chunks/[root-of-the-server]__01rsuhf._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_export_route_actions_0cc~e_r.js")
R.m(51908)
module.exports=R.m(51908).exports
