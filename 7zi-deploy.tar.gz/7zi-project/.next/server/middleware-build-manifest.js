globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Wc1UoRNo5U6ru2u-t741m/_buildManifest.js",
    "static/Wc1UoRNo5U6ru2u-t741m/_ssgManifest.js",
    "static/Wc1UoRNo5U6ru2u-t741m/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ofl8-jevhnao.js",
    "static/chunks/0an_gcdyx8am9.js",
    "static/chunks/09x2-~g9rod5-.js",
    "static/chunks/turbopack-0x4vt-a.pu.rv.js"
  ]
};
