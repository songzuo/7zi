module.exports=[20889,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_github_commits_route_actions_0tz0vqu.js.map