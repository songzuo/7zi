module.exports=[93236,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_health_detailed_route_actions_0o1-ng1.js.map