/**
 * Status API Route
 * System status endpoint
 */

import { NextRequest, NextResponse } from 'next/server';
import logger from '@/lib/logger';

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json({
      success: true,
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: process.env.APP_VERSION || '1.0.0',
    });
  } catch (error) {
    logger.error('Status check failed', error);
    return NextResponse.json(
      {
        success: false,
        status: 'error',
        error: 'Status check failed',
      },
      { status: 500 }
    );
  }
}
