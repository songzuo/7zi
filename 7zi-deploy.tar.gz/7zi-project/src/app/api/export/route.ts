/**
 * Export API Route
 * Data export endpoint
 */

import { NextRequest, NextResponse } from 'next/server';
import logger from '@/lib/logger';

export async function GET(request: NextRequest) {
  try {
    // Check authorization if provided
    const authHeader = request.headers.get('authorization');
    if (authHeader && !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid authorization header',
        },
        { status: 401 }
      );
    }

    // Export formats configuration
    const exportOptions = {
      formats: ['json', 'csv', 'xml'],
      default: 'json',
      maxRecords: 10000,
    };

    return NextResponse.json({
      success: true,
      data: {
        formats: exportOptions.formats,
        default: exportOptions.default,
        maxRecords: exportOptions.maxRecords,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('Export request failed', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Export request failed',
      },
      { status: 500 }
    );
  }
}
