/**
 * GitHub Commits API Route
 * Fetch GitHub commit data
 */

import { NextRequest, NextResponse } from 'next/server';
import logger from '@/lib/logger';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const owner = searchParams.get('owner') || 'owner';
    const repo = searchParams.get('repo') || 'repo';
    const branch = searchParams.get('branch') || 'main';

    // In production, this would fetch from GitHub API
    // For now, return mock data
    const commits = [
      {
        sha: 'abc123',
        message: 'Initial commit',
        author: 'John Doe',
        date: new Date().toISOString(),
      },
    ];

    return NextResponse.json({
      success: true,
      data: commits,
      meta: {
        owner,
        repo,
        branch,
        count: commits.length,
      },
    });
  } catch (error) {
    logger.error('GitHub commits fetch failed', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch commits',
      },
      { status: 500 }
    );
  }
}
