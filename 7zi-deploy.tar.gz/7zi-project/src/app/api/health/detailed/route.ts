/**
 * Health Detailed API Route
 * Detailed health check endpoint
 */

import { NextRequest, NextResponse } from 'next/server';
import logger from '@/lib/logger';
import { getDatabase, getDatabaseSize } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const db = getDatabase();
    const dbSize = getDatabaseSize();

    return NextResponse.json({
      success: true,
      status: 'healthy',
      checks: {
        database: {
          status: db ? 'connected' : 'disconnected',
          size: dbSize,
        },
        memory: {
          heapUsed: process.memoryUsage().heapUsed,
          heapTotal: process.memoryUsage().heapTotal,
          rss: process.memoryUsage().rss,
        },
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    logger.error('Detailed health check failed', error);
    return NextResponse.json(
      {
        success: false,
        status: 'unhealthy',
        error: 'Detailed health check failed',
      },
      { status: 503 }
    );
  }
}
