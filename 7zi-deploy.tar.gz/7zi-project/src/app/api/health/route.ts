/**
 * Health API Route
 * Basic health check endpoint
 */

import { NextRequest, NextResponse } from 'next/server';
import logger from '@/lib/logger';
import { getDatabase } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    // Check database connection
    let dbStatus = 'ok';
    try {
      const db = getDatabase();
      if (!db) {
        dbStatus = 'error';
      }
    } catch (error) {
      dbStatus = 'error';
    }

    return NextResponse.json({
      success: true,
      status: 'healthy',
      checks: {
        database: dbStatus,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    logger.error('Health check failed', error);
    return NextResponse.json(
      {
        success: false,
        status: 'unhealthy',
        error: 'Health check failed',
      },
      { status: 503 }
    );
  }
}
