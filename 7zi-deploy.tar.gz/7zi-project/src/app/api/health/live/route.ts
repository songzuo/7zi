/**
 * Health Live API Route
 * Liveness probe endpoint
 */

import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json({
    status: 'alive',
    timestamp: new Date().toISOString(),
  });
}
