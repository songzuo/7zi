/**
 * Health Ready API Route
 * Readiness probe endpoint
 */

import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    // Check if system is ready to handle requests
    const db = getDatabase();
    const isReady = db !== undefined;

    if (isReady) {
      return NextResponse.json({
        status: 'ready',
        timestamp: new Date().toISOString(),
      });
    } else {
      return NextResponse.json(
        {
          status: 'not_ready',
          error: 'Database not ready',
        },
        { status: 503 }
      );
    }
  } catch (error) {
    return NextResponse.json(
      {
        status: 'not_ready',
        error: 'Readiness check failed',
      },
      { status: 503 }
    );
  }
}
