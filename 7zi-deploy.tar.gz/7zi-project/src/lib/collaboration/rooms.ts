/**
 * Collaboration Rooms
 * Real-time collaboration room management
 */

// ============================================================================
// Types
// ============================================================================

export interface Room {
  id: string;
  name: string;
  type: 'document' | 'whiteboard' | 'code' | 'chat';
  ownerId: string;
  participants: string[];
  createdAt: Date;
  updatedAt: Date;
  metadata?: Record<string, unknown>;
}

export interface RoomMessage {
  id: string;
  roomId: string;
  userId: string;
  type: 'join' | 'leave' | 'message' | 'operation';
  content?: unknown;
  timestamp: Date;
}

// ============================================================================
// In-memory room storage
// ============================================================================

const rooms: Map<string, Room> = new Map();
const roomMessages: Map<string, RoomMessage[]> = new Map();

// ============================================================================
// Room Functions
// ============================================================================

/**
 * Create a new room
 */
export function createRoom(
  name: string,
  type: Room['type'],
  ownerId: string,
  metadata?: Record<string, unknown>
): Room {
  const room: Room = {
    id: `room-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    name,
    type,
    ownerId,
    participants: [],
    createdAt: new Date(),
    updatedAt: new Date(),
    metadata,
  };

  rooms.set(room.id, room);
  roomMessages.set(room.id, []);

  return room;
}

/**
 * Get a room by ID
 */
export function getRoom(roomId: string): Room | undefined {
  return rooms.get(roomId);
}

/**
 * Get all rooms for a user
 */
export function getUserRooms(userId: string): Room[] {
  return Array.from(rooms.values()).filter(
    (room) => room.ownerId === userId || room.participants.includes(userId)
  );
}

/**
 * Join a room
 */
export function joinRoom(roomId: string, userId: string): boolean {
  const room = rooms.get(roomId);
  if (!room) {
    return false;
  }

  if (!room.participants.includes(userId)) {
    room.participants.push(userId);
    room.updatedAt = new Date();
  }

  return true;
}

/**
 * Leave a room
 */
export function leaveRoom(roomId: string, userId: string): boolean {
  const room = rooms.get(roomId);
  if (!room) {
    return false;
  }

  room.participants = room.participants.filter((id) => id !== userId);
  room.updatedAt = new Date();

  return true;
}

/**
 * Delete a room
 */
export function deleteRoom(roomId: string, userId: string): boolean {
  const room = rooms.get(roomId);
  if (!room || room.ownerId !== userId) {
    return false;
  }

  rooms.delete(roomId);
  roomMessages.delete(roomId);

  return true;
}

/**
 * Add a message to a room
 */
export function addRoomMessage(
  roomId: string,
  userId: string,
  type: RoomMessage['type'],
  content?: unknown
): RoomMessage | null {
  const room = rooms.get(roomId);
  if (!room) {
    return null;
  }

  const message: RoomMessage = {
    id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    roomId,
    userId,
    type,
    content,
    timestamp: new Date(),
  };

  const messages = roomMessages.get(roomId) || [];
  messages.push(message);
  roomMessages.set(roomId, messages);

  return message;
}

/**
 * Get messages for a room
 */
export function getRoomMessages(roomId: string, limit?: number): RoomMessage[] {
  const messages = roomMessages.get(roomId) || [];

  if (limit) {
    return messages.slice(-limit);
  }

  return messages;
}

/**
 * Clear messages for a room
 */
export function clearRoomMessages(roomId: string): boolean {
  const room = rooms.get(roomId);
  if (!room) {
    return false;
  }

  roomMessages.set(roomId, []);
  return true;
}
