/**
 * Collaboration Manager
 * Real-time collaboration operations and transforms
 */

// ============================================================================
// Types
// ============================================================================

export interface Operation {
  type: 'insert' | 'delete' | 'retain';
  content?: string;
  length?: number;
  position?: number;
  attributes?: Record<string, unknown>;
}

export interface TextOperation {
  ops: Operation[];
  baseLength: number;
  targetLength: number;
}

export interface TransformResult {
  op1: TextOperation;
  op2: TextOperation;
}

export interface Cursor {
  userId: string;
  userName?: string;
  color?: string;
  x?: number;
  y?: number;
  position?: number;
  selection?: { start: number; end: number };
  timestamp: number;
}

export interface Presence {
  userId: string;
  name: string;
  online: boolean;
  lastSeen: number;
}

// ============================================================================
// Operation Composition
// ============================================================================

/**
 * Compose two operations together
 */
export function composeOperations(op1: TextOperation, op2: TextOperation): TextOperation {
  // Simplified composition logic
  const ops = [...op1.ops, ...op2.ops];
  return {
    ops,
    baseLength: op1.baseLength,
    targetLength: op2.targetLength,
  };
}

// ============================================================================
// Operation Transformation
// ============================================================================

/**
 * Transform operation op against operation otherOp
 * Returns a new operation that can be applied after otherOp
 */
export function transform(op: TextOperation, otherOp: TextOperation): TransformResult {
  // Simplified transformation logic
  // In a real implementation, this would handle concurrent edits properly

  return {
    op1: op,
    op2: otherOp,
  };
}

// ============================================================================
// Operation Application
// ============================================================================

/**
 * Apply an operation to a document
 */
export function applyOperation(doc: string, op: TextOperation): string {
  let result = doc;

  for (const operation of op.ops) {
    switch (operation.type) {
      case 'insert':
        result = operation.content ? result + operation.content : result;
        break;
      case 'delete':
        if (operation.length) {
          result = result.slice(0, -operation.length);
        }
        break;
      case 'retain':
        // Do nothing, just retain existing content
        break;
    }
  }

  return result;
}
